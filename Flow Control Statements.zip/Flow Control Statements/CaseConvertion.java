import java.io.*;
import java.lang.*;
public class CaseConversion
	{
		public static void main(String[] args)
			{
				char c='B';
				if(c>='a' && c<='z')
					{
						c=Character.toUpperCase(c);
						System.out.println(c);
					}
				else if(c>='A' && c<='Z')
					{
						c=Character.toLowerCase(c);
						System.out.println(c);
					}
				else
					{
						System.out.print("Only character allowed");
					}
			}
	}