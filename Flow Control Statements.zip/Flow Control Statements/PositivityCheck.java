import java.io.*;
import java.util.Scanner;
public class PositivityCheck
{
	public static void main(String[] args) 
    		{
			int a;
			Scanner s=new Scanner(System.in);
			System.out.println("Enter a number: ");
			a=s.nextInt();
			if(a>0)
				{
					System.out.println("The given number is Positive");
				}
			else if(a==0)
				{
					System.out.println("The given number is Zero");
				}
			else
				{
					System.out.println("The given number is Negative");
				}
		}
}