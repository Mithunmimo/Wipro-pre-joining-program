import java.io.*;
import java.util.Scanner; 
public class PrimeNumbersRange
	{
		public static void main(String[] args)
			{
				int j=10;
				for(; j<=99; j++)
					{
						int f=0;
						for(int i=2; i<=(j/2); i++)		
							{
								if(j==i)
									{}
								else if((j%i)==0)
									{
										f+=1;	
										break;
									}
							}
						if(f==0)       
							{
								System.out.println(j);
							}
					}
			}	
	}