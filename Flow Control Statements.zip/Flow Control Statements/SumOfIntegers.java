import java.io.*;
import java.util.Scanner;
public class SumOfIntegers
{
	public static void main(String[] args)
		{
			Scanner s= new Scanner(System.in);
			int sum=0,a= s.nextInt();
			for(int i=a;i>=1;)
				{
					int j=(a%10);
					sum=sum+j;
					a=a/10;
					i=a;
				}
			System.out.print(sum);
		}
}