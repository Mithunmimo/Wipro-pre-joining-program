import java.io.*;
import java.util.Scanner;
public class OddOrEven
	{
		public static void main(String[] args)
			{
				Scanner a= new Scanner(System.in);
				System.out.println("Enter a number:");
				int b=a.nextInt();
				if((b%2)==0)
					{
						System.out.println("The given number is Even");
					}
				else
				{
					System.out.println("The given number is Odd");
				}
			}
	}