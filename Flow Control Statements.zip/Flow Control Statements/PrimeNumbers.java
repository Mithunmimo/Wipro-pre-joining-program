import java.io.*;
import java.util.Scanner; 
public class PrimeNumbers
	{
		public static void main(String[] args)
			{
				Scanner s=new Scanner(System.in);
				int f=1,a=s.nextInt();
				for(int i=2; i<=(a/2);i++)		
					{
						if(i==a){}
						else if((a%i)==0)
							{
								System.out.println("The given number is not prime.");
								f+=1;
								break;
							}
					}
				if(f==1)
					{
						System.out.println("The given number is prime.");
					}
			}
	}