import java.io.*;
import java.util.Scanner;
public class Floyd
{
	public static void main(String[] args)
		{
			try
			{
			int a=Integer.parseInt(args[0]);
			for(int i=0;i<a;i++)
				{
				for(int j=0;j<=i;j++)
					{	
						System.out.print("* ");
					}
				System.out.println("");
				}
			}
			catch (Exception e)
				{
					System.out.println("Please eneter an integer");
				}
		}
}		