import java.io.*;
public class ConsolePrimeChecker
	{
		public static void main(String[] args)
			{	try
{
				int f=0;
				int a=Integer.parseInt(args[0]);
				if(a==0 || a==1)
					{
						System.out.println(a+" is neither prime nor composite");
					}
				else
					{
					for(int i=2; i<=(a/2);i++)		
						{
							if(i==a){}
							else if((a%i)==0)
								{
									System.out.println(a+" is not prime.");
									f+=1;
									break;
								}
						}
					if(f==0)	
						{
							System.out.println(a+" is prime.");
						}
					}
				}
catch(Exception e)
{
System.out.println("Please enter an integer number");
}
	}

	}