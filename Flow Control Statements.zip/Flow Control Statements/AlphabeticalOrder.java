import java.io.*;
public class AlphabeticalOrder
	{
		public static void main(String[] args)
			{
				char a='e', b='c';
				if(a>b)
					{
						System.out.println(b+", "+a);
					}
				else
					{
						System.out.println(a+", "+b);
					}
			}
	}