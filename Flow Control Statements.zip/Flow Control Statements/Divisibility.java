import java.io.*;
public class Divisibility
{
	public static void  main(String[] args)
		{	
			int a=1,i=1;
			while(i<=5)
				{
					if(((a%2)==0) && ((a%3)==0) && ((a%5)==0))
						{
							System.out.println(a);
							i++;
							a+=5;
						}
					else
						{
							a++;
						}
				}
		}
}