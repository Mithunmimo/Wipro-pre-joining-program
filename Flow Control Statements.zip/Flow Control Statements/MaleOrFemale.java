import java.io.*;
public class MaleOrFemale
	{
		public static void main(String[] args)
			{
				int a=Integer.parseInt(args[1]);
				String Male="Male", Female="Female";
				if((args[0].equals(Male)))
					{
						if(a>=1 && a<=58)
							{
								System.out.println("The percentage of interest is 8.4%.");
							}	
						else if(a>=59 && a<=100)
							{
								System.out.println("The percentage of interest is 10.4%.");
							}
						else
							{
								System.out.println("Enter a valid age below 100");
							}
					}
					
				else if((args[0].equals(Female)))
					{
						if(a>=1 && a<=58)
							{
								System.out.println("The percentage of interest is 8.2%.");
							}	
						else if(a>=59 && a<=100)
							{
								System.out.println("The percentage of interest is 9.2%.");
							}
						else
							{
								System.out.println("Enter a valid age below 100");
							}
					}
			}
	}